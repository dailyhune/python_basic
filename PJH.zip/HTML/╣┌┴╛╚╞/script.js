// 검색 기능
document.getElementById('searchInput').addEventListener('input', function () {
  const keyword = this.value.toLowerCase();
  const posts = document.querySelectorAll('.post');

  posts.forEach(post => {
    const title = post.querySelector('h2').innerText.toLowerCase();
    const content = post.querySelector('p').innerText.toLowerCase();
    if (title.includes(keyword) || content.includes(keyword)) {
      post.style.display = 'block';
    } else {
      post.style.display = 'none';
    }
  });
});

