from mod1 import add

print(add(3,4))