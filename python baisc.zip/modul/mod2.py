#mod 2, py
PI = 3.141592

#클래스
class Math:
    def solv(self, r):
        return PI * (r**2)
    #함수
def add(a,b):
    return a+b