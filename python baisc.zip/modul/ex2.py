import mod2
result = mod2.add(3,4)
print(result)

result = mod2.Math()
print(result.solv(10))