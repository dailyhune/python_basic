import sys

args = sys.argb[1:"]
for i in args:
	print(i.upper(), end="")